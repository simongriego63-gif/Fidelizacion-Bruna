import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Coffee, 
  MapPin, 
  ShoppingBag, 
  Calendar, 
  Instagram, 
  Facebook, 
  Twitter, 
  Phone,
  ArrowRight,
  Clock
} from 'lucide-react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';

// --- Types ---
type LinkItem = {
  id: string;
  title: string;
  subtitle?: string;
  url: string;
  icon?: React.ReactNode;
  highlight?: boolean;
};

type SocialLink = {
  id: string;
  url: string;
  icon: React.ReactNode;
};

// --- Mock Data ---
const PROFILE_IMG = "https://images.unsplash.com/photo-1630853141918-516c8ea429a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwY29mZmVlJTIwY3VwJTIwbG9nb3xlbnwxfHx8fDE3NzU2OTQ5ODV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";
const PROFILE_NAME = "Aroma & Tueste";
const PROFILE_BIO = "Café de especialidad, panadería artesanal y un espacio para inspirarte. ☕✨";

const BACKGROUNDS = [
  "https://images.unsplash.com/photo-1573840357491-06851c72e0d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBjb2ZmZWUlMjBzaG9wJTIwaW50ZXJpb3J8ZW58MXx8fHwxNzc1Njk0OTg1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  "https://images.unsplash.com/photo-1630439922869-50635c8b2335?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXJpc3RhJTIwcG91cmluZyUyMGxhdHRlJTIwYXJ0fGVufDF8fHx8MTc3NTU4OTA5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  "https://images.unsplash.com/photo-1649777888193-e47833d91521?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjBiZWFucyUyMGRhcmslMjBhZXN0aGV0aWN8ZW58MXx8fHwxNzc1NjUyNjE5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
];

const LINKS: LinkItem[] = [
  {
    id: 'menu',
    title: 'Ver Nuestro Menú',
    subtitle: 'Bebidas, postres y comida salada',
    url: '#',
    icon: <Coffee size={22} />,
    highlight: true,
  },
  {
    id: 'order',
    title: 'Pide a Domicilio',
    subtitle: 'UberEats, Rappi y DidiFood',
    url: '#',
    icon: <ShoppingBag size={22} />,
  },
  {
    id: 'reservations',
    title: 'Reserva una Mesa',
    subtitle: 'Ideal para juntas o citas',
    url: '#',
    icon: <Calendar size={22} />,
  },
  {
    id: 'location',
    title: 'Encuéntranos',
    subtitle: 'Av. Principal 123, Centro Histórico',
    url: '#',
    icon: <MapPin size={22} />,
  },
];

const SOCIAL_LINKS: SocialLink[] = [
  { id: 'instagram', url: '#', icon: <Instagram size={22} /> },
  { id: 'facebook', url: '#', icon: <Facebook size={22} /> },
  { id: 'twitter', url: '#', icon: <Twitter size={22} /> },
  { id: 'whatsapp', url: '#', icon: <Phone size={22} /> },
];

export default function App() {
  const [currentBg, setCurrentBg] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBg((prev) => (prev + 1) % BACKGROUNDS.length);
    }, 5000); // Change image every 5 seconds
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-neutral-950 text-amber-50 font-sans relative overflow-hidden selection:bg-amber-600/30">
      
      {/* Dynamic Backgrounds */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <AnimatePresence>
          <motion.div
            key={currentBg}
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${BACKGROUNDS[currentBg]})` }}
          />
        </AnimatePresence>
        
        {/* Overlays for contrast and modern glassmorphism */}
        <div className="absolute inset-0 bg-neutral-950/70 backdrop-blur-[2px]" />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-neutral-950/40" />
      </div>

      {/* Main Content */}
      <main className="relative z-10 w-full max-w-md mx-auto px-5 py-16 flex flex-col items-center min-h-screen">
        
        {/* Header / Profile Section */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="flex flex-col items-center text-center mb-10 w-full"
        >
          <div className="relative mb-5 group">
            {/* Soft glow behind avatar */}
            <div className="absolute inset-0 bg-amber-600 rounded-full blur-xl opacity-30 group-hover:opacity-50 transition-opacity duration-500" />
            <ImageWithFallback
              src={PROFILE_IMG}
              alt={PROFILE_NAME}
              className="relative w-28 h-28 rounded-full object-cover border-[3px] border-amber-500/30 shadow-2xl transition-transform duration-500 group-hover:scale-105"
            />
          </div>
          <h1 className="text-3xl font-semibold tracking-tight mb-3 text-white">
            {PROFILE_NAME}
          </h1>
          <p className="text-amber-100/70 text-sm max-w-[280px] leading-relaxed">
            {PROFILE_BIO}
          </p>
          
          <div className="mt-4 flex items-center gap-2 text-xs font-medium px-3 py-1.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 backdrop-blur-md">
            <Clock size={12} className="animate-pulse" />
            <span>Abierto ahora • 8:00 AM - 10:00 PM</span>
          </div>
        </motion.div>

        {/* Links Section */}
        <div className="w-full flex flex-col gap-4 mb-10">
          {LINKS.map((link, index) => (
            <motion.a
              key={link.id}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
              className={`
                group relative flex items-center p-4 rounded-2xl 
                backdrop-blur-md transition-all duration-300 overflow-hidden
                ${link.highlight 
                  ? 'bg-amber-600/20 border border-amber-500/40 hover:bg-amber-600/30 hover:border-amber-400/60 shadow-[0_4px_20px_rgba(217,119,6,0.15)]' 
                  : 'bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20'
                }
              `}
            >
              {/* Highlight gradient sweep effect */}
              {link.highlight && (
                <div className="absolute inset-0 translate-x-[-100%] group-hover:animate-[shimmer_2s_infinite] bg-gradient-to-r from-transparent via-white/10 to-transparent skew-x-12" />
              )}
              
              <div className="flex items-center gap-4 w-full relative z-10">
                <div className={`
                  flex items-center justify-center w-12 h-12 rounded-xl shrink-0
                  ${link.highlight ? 'bg-amber-500/20 text-amber-300' : 'bg-white/5 text-amber-100/80'}
                  group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300
                `}>
                  {link.icon}
                </div>
                
                <div className="flex flex-col flex-1 text-left">
                  <span className={`font-medium text-[15px] ${link.highlight ? 'text-amber-50' : 'text-white'}`}>
                    {link.title}
                  </span>
                  {link.subtitle && (
                    <span className="text-xs text-amber-100/50 mt-0.5 line-clamp-1">
                      {link.subtitle}
                    </span>
                  )}
                </div>
                
                <div className={`
                  w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all duration-300
                  ${link.highlight ? 'bg-amber-500/20 text-amber-300 group-hover:bg-amber-500 group-hover:text-white' : 'bg-white/5 text-white/50 group-hover:bg-white/10 group-hover:text-white'}
                `}>
                  <ArrowRight size={16} className="group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            </motion.a>
          ))}
        </div>

        {/* Social Media Section */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="flex items-center gap-4 mt-auto mb-8"
        >
          {SOCIAL_LINKS.map((social) => (
            <motion.a
              key={social.id}
              href={social.url}
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ y: -4, scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-amber-100/70 hover:bg-amber-600/20 hover:text-amber-300 hover:border-amber-500/30 transition-all duration-300 backdrop-blur-md shadow-lg"
            >
              {social.icon}
            </motion.a>
          ))}
        </motion.div>

        {/* Footer */}
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.9 }}
          className="text-xs text-amber-100/40 text-center"
        >
          © {new Date().getFullYear()} {PROFILE_NAME}. Todos los derechos reservados.
        </motion.p>
      </main>

      {/* Global styles for animations not included in standard Tailwind */}
      <style>{`
        @keyframes shimmer {
          100% {
            transform: translateX(200%);
          }
        }
      `}</style>
    </div>
  );
}
