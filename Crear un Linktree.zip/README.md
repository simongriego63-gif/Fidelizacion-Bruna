
  # Crear un Linktree

  This is a code bundle for Crear un Linktree. The original project is available at https://www.figma.com/design/uv0lPX0HXn4HuaWm7pcg0H/Crear-un-Linktree.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  